from setuptools import setup

setup(
    name="paquete-lcdpanel16x2-MySecurityTouch",
    version="0.1",
    description="Este es un paquete que gestiona la pantalla lcd 16x2 del administrador de acceso inteligente de My Security Touch",
    author="Felipe Diaz",
    author_email="felipe.diaz105@inacapmail.cl",
    url="http://MySecurityTouch.cl",
    scripts=[],
    packages=["lcdpanel"]
)